const mongoose = require('mongoose');

const VideoSchema = new mongoose.Schema({
  title: String,
  url: String,
  views: { type: Number, default: 0 }
});

module.exports = mongoose.model('Video', VideoSchema);
