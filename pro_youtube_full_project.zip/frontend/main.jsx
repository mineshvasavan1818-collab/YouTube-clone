import React from 'react';
import ReactDOM from 'react-dom/client';

function App(){
  return (
    <div style={{padding:20}}>
      <h1>🚀 Pro YouTube v1</h1>
      <p>Frontend Running</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
